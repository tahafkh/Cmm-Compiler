package main.ast.types.primitives;

import main.ast.types.Type;

public class VoidType extends Type {
    @Override
    public String toString() {
        return "VoidType";
    }
}
